#!/usr/bin/env bash
# Replay the four controls for one task and write the results into meta.json.
#
#   verify_task.sh <repo-clone> <task-dir>
#
# Controls
#   base       BASE unchanged            behavior must fail, regression must pass
#   reference  BASE + reference/pr.diff  behavior must pass, regression must pass
#   empty      BASE + empty commit       behavior must fail, regression must pass
#   probe      BASE + reference/probe.diff  behavior must fail, regression recorded
#
# Each verifier exits 0 pass, 1 fail, anything else infra. The repo clone is
# never modified. Every control runs in a fresh git worktree that is removed
# afterwards. Requires python3 and jq-free (uses python for JSON).
set -u

REPO=$(cd "$1" && pwd) || exit 2
TASK=$(cd "$2" && pwd) || exit 2
META="$TASK/meta.json"
RUN="$TASK/hidden_test/run.sh"

die() { echo "verify_task: $*" >&2; exit 2; }
[ -f "$META" ] || die "missing $META"
[ -x "$RUN" ] || die "missing or non-executable $RUN"

field() { python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); v=d.get(sys.argv[2],""); print(v if isinstance(v,str) else json.dumps(v))' "$META" "$1"; }
BASE_SHA=$(field base_sha)
INSTALL_CMD=$(field install_command)
TEST_CMD=$(field test_command)
[ -n "$BASE_SHA" ] || die "meta.json.base_sha is empty"
[ -n "$TEST_CMD" ] || die "meta.json.test_command is empty"
git -C "$REPO" cat-file -e "$BASE_SHA^{commit}" 2>/dev/null || die "base_sha $BASE_SHA not in $REPO"

WORK=$(mktemp -d "${TMPDIR:-/tmp}/eval-verify.XXXXXX")
cleanup() {
  for w in "$WORK"/*/; do git -C "$REPO" worktree remove --force "$w" >/dev/null 2>&1 || true; done
  rm -rf "$WORK"
}
trap cleanup EXIT

# verdict <exit-code> -> pass | fail | unmeasured
verdict() { case "$1" in 0) echo pass;; 1) echo fail;; *) echo unmeasured;; esac; }

# run_verifier <worktree> <label> <command...>  prints exit code, logs output
run_cmd() {
  local wt=$1 label=$2; shift 2
  local log="$TASK/controls/$CONTROL.$label.log"
  ( cd "$wt" && EVAL_BASE_SHA="$BASE_SHA" bash -lc "$*" ) >"$log" 2>&1
  local rc=$?
  echo "$rc"
}

mkdir -p "$TASK/controls"
declare -A BEH REG INFRA

for CONTROL in base reference empty probe; do
  WT="$WORK/$CONTROL"
  git -C "$REPO" worktree add --detach "$WT" "$BASE_SHA" >/dev/null 2>&1 || die "worktree add failed for $CONTROL"
  case $CONTROL in
    reference) git -C "$WT" apply --index "$TASK/reference/pr.diff" || { INFRA[$CONTROL]=infra_error; BEH[$CONTROL]=unmeasured; REG[$CONTROL]=unmeasured; echo "$CONTROL: pr.diff did not apply"; continue; } ;;
    probe)     [ -f "$TASK/reference/probe.diff" ] || die "missing reference/probe.diff"
               git -C "$WT" apply --index "$TASK/reference/probe.diff" || { INFRA[$CONTROL]=infra_error; BEH[$CONTROL]=unmeasured; REG[$CONTROL]=unmeasured; echo "$CONTROL: probe.diff did not apply"; continue; } ;;
    empty)     git -C "$WT" -c user.name=eval -c user.email=eval@local commit --allow-empty -qm "empty" ;;
  esac

  if [ -n "$INSTALL_CMD" ]; then
    rc=$(run_cmd "$WT" install "$INSTALL_CMD")
    if [ "$rc" != 0 ]; then INFRA[$CONTROL]=infra_error; BEH[$CONTROL]=unmeasured; REG[$CONTROL]=unmeasured; echo "$CONTROL: install failed (exit $rc)"; continue; fi
  fi

  # behavior verifier. run.sh must not leave changes that the regression run would see,
  # so run regression first on a clean tree, then the hidden test.
  rc_reg=$(run_cmd "$WT" regression "$TEST_CMD")
  rc_beh=$(run_cmd "$WT" behavior "\"$RUN\" \"$WT\"")

  BEH[$CONTROL]=$(verdict "$rc_beh")
  REG[$CONTROL]=$(verdict "$rc_reg")
  if [ "${BEH[$CONTROL]}" = unmeasured ] || [ "${REG[$CONTROL]}" = unmeasured ]; then INFRA[$CONTROL]=infra_error; else INFRA[$CONTROL]=ok; fi
  printf '%-10s behavior=%-10s regression=%-10s infra=%s\n' "$CONTROL" "${BEH[$CONTROL]}" "${REG[$CONTROL]}" "${INFRA[$CONTROL]}"
done

python3 - "$META" \
  "${BEH[base]:-unmeasured}" "${REG[base]:-unmeasured}" "${INFRA[base]:-infra_error}" \
  "${BEH[reference]:-unmeasured}" "${REG[reference]:-unmeasured}" "${INFRA[reference]:-infra_error}" \
  "${BEH[empty]:-unmeasured}" "${REG[empty]:-unmeasured}" "${INFRA[empty]:-infra_error}" \
  "${BEH[probe]:-unmeasured}" "${REG[probe]:-unmeasured}" "${INFRA[probe]:-infra_error}" <<'PY'
import json, sys
meta_path = sys.argv[1]; v = sys.argv[2:]
names = ["base", "reference", "empty", "probe"]
controls = {n: {"behavior": v[i*3], "regression": v[i*3+1], "infra_status": v[i*3+2]} for i, n in enumerate(names)}
meta = json.load(open(meta_path))
meta["controls"] = controls
json.dump(meta, open(meta_path, "w"), indent=2); open(meta_path, "a").write("\n")

expected = {"base": ("fail", "pass"), "reference": ("pass", "pass"), "empty": ("fail", "pass")}
problems = []
for n, (b, r) in expected.items():
    c = controls[n]
    if c["infra_status"] != "ok": problems.append(f"{n}: infra_error, control unmeasured")
    if c["behavior"] != b: problems.append(f"{n}: behavior {c['behavior']}, expected {b}")
    if c["regression"] != r: problems.append(f"{n}: regression {c['regression']}, expected {r}")
p = controls["probe"]
if p["infra_status"] != "ok": problems.append("probe: infra_error, control unmeasured")
elif p["behavior"] != "fail": problems.append(f"probe: behavior {p['behavior']}, expected fail. Strengthen the verifier, never weaken the probe")
if problems:
    print("CONTROLS NOT SATISFIED"); [print("  " + x) for x in problems]; sys.exit(1)
print("controls satisfied")
PY
