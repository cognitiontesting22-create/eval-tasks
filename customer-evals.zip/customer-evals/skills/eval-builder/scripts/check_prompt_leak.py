#!/usr/bin/env python3
"""Check task.md for spoilers and size.

    check_prompt_leak.py <task-dir>

Reads task.md, meta.json (files_touched, pr_number, issue_url) and
reference/pr.diff. Exit 0 clean, 1 findings, 2 malformed task folder.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

BANNED_WORDS = re.compile(r"\b(eval|evals|evaluation|hidden test|reference solution|benchmark|answer key|golden)\b", re.I)
IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_]{5,}")
COMMON = {"should", "expected", "behavior", "behaviour", "command", "running", "return", "returns", "output", "instead",
          "example", "current", "correct", "following", "without", "because", "before", "after", "please", "existing",
          "include", "tests", "passing", "change", "changes", "request", "requests", "option", "options", "default",
          "argument", "arguments", "function", "response", "string", "header", "headers", "python", "typescript"}
MAX_WORDS = 300


def added_identifiers(diff: str) -> set[str]:
    """Identifiers that appear on added source lines and not on any removed or context line."""
    added, other = set(), set()
    for line in diff.splitlines():
        if line.startswith("+++") or line.startswith("---"):
            continue
        target = added if line.startswith("+") else other
        target.update(IDENT.findall(line[1:] if line[:1] in "+- " else line))
    return added - other


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__); return 2
    task = Path(sys.argv[1]).resolve()
    prompt_path, meta_path, diff_path = task / "task.md", task / "meta.json", task / "reference" / "pr.diff"
    for p in (prompt_path, meta_path):
        if not p.is_file():
            print(f"missing {p}"); return 2
    prompt = prompt_path.read_text()
    meta = json.loads(meta_path.read_text())
    lowered = prompt.lower()
    findings: list[str] = []

    words = len(prompt.split())
    if words > MAX_WORDS:
        findings.append(f"prompt is {words} words, limit {MAX_WORDS}")

    touched = meta.get("files_touched", {})
    for path in touched.get("source", []) + touched.get("test", []):
        stem = Path(path).stem
        generic = stem.lower() in {"__init__", "index", "main", "utils", "types", "mod", "lib"} or stem.startswith("test")
        if path.lower() in lowered:
            findings.append(f"names touched file {path}")
        elif len(stem) > 3 and not generic and re.search(rf"\b{re.escape(stem)}\b", prompt):
            findings.append(f"names touched file basename {stem} ({path})")

    numbers = set()
    if meta.get("pr_number"):
        numbers.add(str(meta["pr_number"]))
    m = re.search(r"/(?:issues|pull)/(\d+)", meta.get("issue_url") or "")
    if m:
        numbers.add(m.group(1))
    for n in numbers:
        if re.search(rf"(?<![\w.])#?{n}\b", prompt) and re.search(rf"#\s?{n}\b|\b(?:issue|pr|pull request)\s+#?{n}\b", prompt, re.I):
            findings.append(f"mentions issue or PR number {n}")

    for m in BANNED_WORDS.finditer(prompt):
        findings.append(f"banned word {m.group(0)!r}")

    if diff_path.is_file():
        new_idents = added_identifiers(diff_path.read_text(errors="replace"))
        prompt_idents = set(IDENT.findall(prompt))
        leaked = sorted(i for i in new_idents & prompt_idents if i.lower() not in COMMON)
        for i in leaked:
            findings.append(f"identifier introduced by the fix appears in the prompt: {i}")
    else:
        findings.append("reference/pr.diff missing, identifier check skipped")

    if findings:
        print(f"PROMPT LEAK CHECK: {len(findings)} finding(s)")
        for f in findings:
            print("  " + f)
        return 1
    print(f"prompt leak check clean ({words} words)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
