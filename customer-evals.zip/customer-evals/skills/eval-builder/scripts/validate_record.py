#!/usr/bin/env python3
"""Strictly validate meta.json and the task folder layout, then compute the emit or reject decision.

    validate_record.py <task-dir> [--write-decision]

Exit 0 when the record is valid and every required control holds (EMIT),
1 when the record is valid but the task must be rejected, 2 when malformed.
With --write-decision, writes decision.md and sets meta.decision.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

REQUIRED = {
    "schema": str, "id": str, "repo": str, "base_sha": str, "merge_sha": str, "pr_number": int, "pr_url": str,
    "pr_source": str, "merged_at": str, "difficulty": str, "language": str, "toolchain": dict, "install_command": str,
    "test_command": str, "timeout_minutes": int, "request_source": str, "trace_source": str, "engineer_qa": str,
    "mcp_dependencies": list, "lifted_into_prompt": list, "spoilers_stripped": list, "files_touched": dict,
    "prompt_word_count": int, "prompt_approved": dict, "configurations": list, "contamination": dict,
    "controls": dict, "probe_description": str, "lint": str, "prompt_leak_check": str, "decision": str,
    "decision_reason": str, "built_at": str, "builder": str,
}
OPTIONAL = {"upstream_repo": str, "fork_url": str, "base_branch": str, "issue_url": str, "spare": bool}
ENUMS = {
    "schema": {"customer-evals.task/1"},
    "difficulty": {"easy", "medium", "hard"},
    "request_source": {"trace", "issue", "pr_description", "engineer"},
    "trace_source": {"devin_session", "local_log", "none"},
    "lint": {"clean", "failed", "not_run"},
    "prompt_leak_check": {"clean", "failed", "not_run"},
    "decision": {"EMIT", "REJECT", "PENDING"},
}
CONTROL_NAMES = ["base", "reference", "empty", "probe"]
VERDICTS = {"pass", "fail", "unmeasured"}
LAYOUT = ["task.md", "criteria.md", "hidden_test/run.sh", "verifiers.json", "reference/pr.diff",
          "reference/request.md", "reference/probe.diff"]


def validate(task: Path, meta: dict) -> list[str]:
    errors: list[str] = []
    unknown = set(meta) - set(REQUIRED) - set(OPTIONAL)
    if unknown:
        errors.append(f"unknown fields {sorted(unknown)}")
    for k, t in REQUIRED.items():
        if k not in meta:
            errors.append(f"missing {k}")
        elif not isinstance(meta[k], t) or (t is int and isinstance(meta[k], bool)):
            errors.append(f"{k} must be {t.__name__}")
    for k, t in OPTIONAL.items():
        if k in meta and not isinstance(meta[k], t):
            errors.append(f"{k} must be {t.__name__}")
    for k, allowed in ENUMS.items():
        if k in meta and meta[k] not in allowed:
            errors.append(f"{k} must be one of {sorted(allowed)}")
    if meta.get("id") != task.name:
        errors.append(f"id {meta.get('id')!r} does not match folder name {task.name!r}")
    for rel in LAYOUT:
        if not (task / rel).is_file():
            errors.append(f"missing {rel}")
    if meta.get("trace_source") not in (None, "none") and not (task / "reference" / "trace-summary.md").is_file():
        errors.append("trace_source set but reference/trace-summary.md missing")
    ft = meta.get("files_touched", {})
    if set(ft) - {"source", "test"} or not isinstance(ft.get("source"), list):
        errors.append("files_touched must have source and test lists")
    pa = meta.get("prompt_approved", {})
    if set(pa) != {"by", "at"}:
        errors.append("prompt_approved must have exactly by and at")
    lifted = meta.get("lifted_into_prompt", [])
    for dep in meta.get("mcp_dependencies", []):
        if not any(dep in str(x) for x in lifted):
            errors.append(f"mcp dependency {dep!r} has no entry in lifted_into_prompt")
    contam = meta.get("contamination", {})
    if set(contam) - {"pr_merged_at", "model_release_dates"}:
        errors.append("contamination allows only pr_merged_at and model_release_dates")
    controls = meta.get("controls", {})
    if set(controls) != set(CONTROL_NAMES):
        errors.append(f"controls must have exactly {CONTROL_NAMES}")
    for n in CONTROL_NAMES:
        c = controls.get(n, {})
        if set(c) != {"behavior", "regression", "infra_status"}:
            errors.append(f"controls.{n} must have behavior, regression, infra_status")
            continue
        if c["behavior"] not in VERDICTS or c["regression"] not in VERDICTS:
            errors.append(f"controls.{n} verdicts must be pass, fail, or unmeasured")
        if c["infra_status"] not in {"ok", "infra_error"}:
            errors.append(f"controls.{n}.infra_status must be ok or infra_error")
    if meta.get("timeout_minutes", 1) <= 0:
        errors.append("timeout_minutes must be positive")
    if meta.get("prompt_word_count", 0) > 300:
        errors.append("prompt_word_count over 300")
    return errors


def decide(task: Path, meta: dict) -> tuple[str, str]:
    c = meta["controls"]
    checks = [
        (c["base"]["infra_status"] == "ok" and c["base"]["behavior"] == "fail", "behavior verifier does not fail at base"),
        (c["base"]["regression"] == "pass", "existing suite does not pass at base"),
        (c["reference"]["infra_status"] == "ok" and c["reference"]["behavior"] == "pass", "reference patch does not pass the behavior verifier"),
        (c["reference"]["regression"] == "pass", "existing suite does not pass on the reference patch"),
        (c["empty"]["infra_status"] == "ok" and c["empty"]["behavior"] == "fail", "empty patch does not fail the behavior verifier"),
        (c["probe"]["infra_status"] == "ok" and c["probe"]["behavior"] == "fail", "probe does not fail the behavior verifier"),
        (meta["lint"] == "clean", "verifier lint not clean"),
        (meta["prompt_leak_check"] == "clean", "prompt leak check not clean"),
        (bool(meta["prompt_approved"].get("by")) and bool(meta["prompt_approved"].get("at")), "frozen prompt not approved"),
        (len(meta["files_touched"].get("source", [])) > 0, "no source files touched, nothing to evaluate"),
    ]
    for ok, reason in checks:
        if not ok:
            return "REJECT", reason
    return "EMIT", "all required controls hold"


def write_decision(task: Path, meta: dict, decision: str, reason: str) -> None:
    c = meta["controls"]
    lines = [decision, "", reason, "", "| control | behavior | regression | infra |", "|---|---|---|---|"]
    lines += [f"| {n} | {c[n]['behavior']} | {c[n]['regression']} | {c[n]['infra_status']} |" for n in CONTROL_NAMES]
    lines += ["", f"probe: {meta['probe_description']}", ""]
    (task / "decision.md").write_text("\n".join(lines))
    meta["decision"], meta["decision_reason"] = decision, reason
    (task / "meta.json").write_text(json.dumps(meta, indent=2) + "\n")


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    write = "--write-decision" in sys.argv
    if len(args) != 1:
        print(__doc__); return 2
    task = Path(args[0]).resolve()
    mp = task / "meta.json"
    if not mp.is_file():
        print(f"missing {mp}"); return 2
    try:
        meta = json.loads(mp.read_text())
    except json.JSONDecodeError as e:
        print(f"meta.json is not valid JSON: {e}"); return 2
    errors = validate(task, meta)
    if errors:
        print(f"RECORD INVALID ({len(errors)})")
        for e in errors:
            print("  " + e)
        return 2
    decision, reason = decide(task, meta)
    if write:
        write_decision(task, meta, decision, reason)
    print(f"{decision}: {reason}")
    return 0 if decision == "EMIT" else 1


if __name__ == "__main__":
    sys.exit(main())
