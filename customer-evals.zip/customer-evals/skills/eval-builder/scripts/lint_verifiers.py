#!/usr/bin/env python3
"""Lint the hidden test scripts and verifiers.json of one task.

    lint_verifiers.py <task-dir>

Exit 0 when clean, 1 when any rule fires, 2 when the task folder is malformed.
Rules follow experimental/deniz/prod_to_eval_v2/verifiers.py in devin-datagen.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

SOURCE_GREP = re.compile(r"\b(grep|rg|ag|ack|sed|awk)\b[^\n|;&]*\.(py|ts|tsx|js|jsx|go|rs|java|rb|kt|swift|c|cc|cpp|h|hpp|cs|php|scala)\b")
AST_INSPECT = re.compile(r"\bimport\s+ast\b|\bast\.parse\(|\binspect\.getsource\(|\bgo/ast\b|\bts\.createSourceFile\(|\b@babel/parser\b")
PRIVATE_HELPER = re.compile(r"(?<![\w.])(from\s+[\w.]+\s+import\s+_\w+|[\w.]+\._[a-zA-Z]\w*\()")
GIT_HEAD = re.compile(r"\bgit\s+(-C\s+\S+\s+)?(diff|log|show|status)\b(?![^\n]*\$EVAL_BASE_SHA)")
MOCKS = re.compile(r"unittest\.mock|from\s+unittest\s+import\s+mock|\bmonkeypatch\.setattr\b|jest\.mock\(|vi\.mock\(|sinon\.stub|\bgomock\b")
CATEGORIES = {"behavior", "regression", "test_authoring", "scope", "criterion", "process"}
ALWAYS_BLOCK = {"behavior", "regression"}
BUILTINS = {"existing_suite", "no_tree_changes", "files_untouched"}
SOURCE_KINDS = {"user_message", "user_correction", "repository", "historical_pr"}
CONTROL_VALUES = {"pass", "fail", "recorded"}
VERIFIER_FIELDS = {"id", "category", "blocking", "user_stated", "weight", "requirement", "source", "check",
                   "accepted_alternatives", "plausible_wrong", "controls", "rationale"}


def cite(path: Path, text: str, m: re.Match[str]) -> str:
    line_no = text.count("\n", 0, m.start()) + 1
    line = text.splitlines()[line_no - 1].strip()
    return f"{path.name} line {line_no}: {line[:160]}"


def lint_scripts(task: Path, verifiers: dict) -> list[str]:
    errors: list[str] = []
    justified = {v["check"].get("path") for v in verifiers.get("verifiers", [])
                 if v.get("check", {}).get("type") == "script" and v["check"].get("mock_justification")}
    hidden = task / "hidden_test"
    if not hidden.is_dir():
        return ["hidden_test/ is missing"]
    for path in sorted(p for p in hidden.rglob("*") if p.is_file()):
        text = path.read_text(errors="replace")
        for m in SOURCE_GREP.finditer(text):
            errors.append("source grep: " + cite(path, text, m))
        for m in AST_INSPECT.finditer(text):
            errors.append("AST inspection: " + cite(path, text, m))
        for m in PRIVATE_HELPER.finditer(text):
            errors.append("private helper: " + cite(path, text, m))
        for m in GIT_HEAD.finditer(text):
            errors.append("HEAD-relative git, diff against $EVAL_BASE_SHA: " + cite(path, text, m))
        rel = str(path.relative_to(task))
        if rel not in justified:
            for m in MOCKS.finditer(text):
                errors.append("mock without mock_justification: " + cite(path, text, m))
    run = hidden / "run.sh"
    if not run.is_file():
        errors.append("hidden_test/run.sh is missing")
    elif "$1" not in run.read_text() and "${1" not in run.read_text():
        errors.append("hidden_test/run.sh must take the repo path as $1")
    return errors


def lint_set(task: Path, vs: dict) -> list[str]:
    errors: list[str] = []
    if vs.get("schema") != "customer-evals.verifiers/1":
        errors.append("verifiers.json schema must be customer-evals.verifiers/1")
    extra = set(vs) - {"schema", "task_id", "verifiers"}
    if extra:
        errors.append(f"verifiers.json unknown top-level fields {sorted(extra)}")
    if vs.get("task_id") != task.name:
        errors.append(f"verifiers.json task_id {vs.get('task_id')!r} does not match folder {task.name!r}")
    rows = vs.get("verifiers") or []
    ids = [r.get("id") for r in rows]
    if len(set(ids)) != len(ids):
        errors.append("duplicate verifier id")
    cats = [r.get("category") for r in rows]
    if "behavior" not in cats:
        errors.append("at least one behavior verifier is required")
    if cats.count("regression") != 1:
        errors.append("exactly one regression verifier is required")
    for r in rows:
        rid = r.get("id", "?")
        extra = set(r) - VERIFIER_FIELDS
        missing = VERIFIER_FIELDS - set(r)
        if extra:
            errors.append(f"{rid}: unknown fields {sorted(extra)}")
        if missing:
            errors.append(f"{rid}: missing fields {sorted(missing)}")
        if not re.fullmatch(r"[a-z][a-z0-9_]{2,63}", str(rid)):
            errors.append(f"{rid}: id must be snake_case")
        cat = r.get("category")
        if cat not in CATEGORIES:
            errors.append(f"{rid}: unknown category {cat!r}")
        if cat in ALWAYS_BLOCK and r.get("blocking") is not True:
            errors.append(f"{rid}: {cat} verifiers must be blocking")
        if cat not in ALWAYS_BLOCK and r.get("blocking") and not r.get("user_stated"):
            errors.append(f"{rid}: {cat} may block only when user_stated is true")
        if not isinstance(r.get("weight"), (int, float)) or r.get("weight", 0) <= 0:
            errors.append(f"{rid}: weight must be a positive number")
        src = r.get("source") or {}
        if src.get("kind") not in SOURCE_KINDS or not src.get("quote"):
            errors.append(f"{rid}: source needs kind in {sorted(SOURCE_KINDS)} and a quote")
        if src.get("kind") in {"user_message", "user_correction"} and not isinstance(src.get("event_index"), int):
            errors.append(f"{rid}: user-sourced requirements must cite event_index")
        chk = r.get("check") or {}
        t = chk.get("type")
        if t == "script":
            p = chk.get("path", "")
            if not p.startswith("hidden_test/") or not p.endswith(".sh"):
                errors.append(f"{rid}: script checks live at hidden_test/<name>.sh")
            elif not (task / p).is_file():
                errors.append(f"{rid}: {p} does not exist")
        elif t == "builtin":
            if chk.get("name") not in BUILTINS:
                errors.append(f"{rid}: unknown builtin {chk.get('name')!r}, known {sorted(BUILTINS)}")
        elif t == "llm_judge":
            for f in ("criterion", "pass_rule", "evidence", "deterministic_infeasible"):
                if not chk.get(f):
                    errors.append(f"{rid}: llm_judge needs {f}")
            if r.get("blocking"):
                errors.append(f"{rid}: llm_judge checks are never blocking on their own")
        else:
            errors.append(f"{rid}: check.type must be script, builtin, or llm_judge")
        ctl = r.get("controls") or {}
        if ctl.get("reference") != "pass":
            errors.append(f"{rid}: controls.reference must be pass")
        for k in ("empty", "probe"):
            if ctl.get(k) not in CONTROL_VALUES:
                errors.append(f"{rid}: controls.{k} must be one of {sorted(CONTROL_VALUES)}")
        if cat == "behavior":
            if ctl.get("empty") != "fail" or ctl.get("probe") != "fail":
                errors.append(f"{rid}: behavior verifiers must fail on empty and probe")
            if not r.get("accepted_alternatives"):
                errors.append(f"{rid}: behavior verifiers must name at least one accepted alternative")
        if not r.get("requirement") or not r.get("rationale"):
            errors.append(f"{rid}: requirement and rationale are required")
    return errors


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__); return 2
    task = Path(sys.argv[1]).resolve()
    vpath = task / "verifiers.json"
    if not vpath.is_file():
        print(f"missing {vpath}"); return 2
    try:
        vs = json.loads(vpath.read_text())
    except json.JSONDecodeError as e:
        print(f"verifiers.json is not valid JSON: {e}"); return 2
    errors = lint_set(task, vs) + lint_scripts(task, vs)
    if errors:
        print(f"LINT FAILED ({len(errors)})")
        for e in errors:
            print("  " + e)
        return 1
    print("lint clean")
    return 0


if __name__ == "__main__":
    sys.exit(main())
