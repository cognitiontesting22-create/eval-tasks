# Verifier rules

Adapted from `experimental/deniz/prod_to_eval_v2` in `cognition-research/devin-datagen` (Gridiron). The heavy parts of that pipeline (Evalon, pre-AMI snapshots, multi-model rollout audit) are not needed here. The contract below is the portable part.

## Categories

| Category | Blocking | Meaning |
|---|---|---|
| `behavior` | always | the requested behavior is observable through the public surface |
| `regression` | always | the existing suite still passes |
| `test_authoring` | only if the engineer stated it | the agent added tests of the required kind |
| `scope` | only if the engineer stated it | the change stays inside the named area, or leaves named files untouched |
| `criterion` | only if the engineer stated it | a specific acceptance criterion from the Q&A |
| `process` | only if the engineer stated it | how the work was done, for example ran the suite before finishing |

Correctness is the blocking rows only. Advisory rows feed a 0 to 100 quality score and never compensate for a blocking fail.

## Check types

- `script`. A shell script under `hidden_test/`. Run with the repo path as `$1` and `EVAL_BASE_SHA` exported. Exit 0 pass, 1 fail, anything else infra.
- `builtin`. Pipeline-owned checks referenced by name. Available here `existing_suite` (runs `meta.json.test_command`), `no_tree_changes` (fails when the diff against `EVAL_BASE_SHA` is empty), `files_untouched` (fails when any listed path changed).
- `llm_judge`. Only when a deterministic check is infeasible, and `deterministic_infeasible` must say why. Judges read `final_message`, `diff`, `tool_calls`, or `all_messages`. Never blocking on its own.

## Lint rules, from `verifiers.py`

A verifier is rejected when its script

- greps, seds, or awks a source file for a symbol or string
- parses the AST or imports a module only to inspect attributes
- imports or calls a private helper (leading underscore, unexported, or named in the reference diff but not in the public API)
- uses `git diff HEAD`, `git status`, or any HEAD-relative comparison. Diff against `$EVAL_BASE_SHA`
- mocks or monkeypatches without `mock_justification`
- asserts exact output text unless the request demanded that exact text (`exact_output_required` quotes it)

`scripts/lint_verifiers.py` implements the pattern checks. Human review still matters. A test that passes lint but only accepts the original PR's approach is still wrong.

## Controls

Every verifier declares what the controls should produce. The preflight replays them.

| Control | What is graded | behavior | regression |
|---|---|---|---|
| `base` | BASE with no change | fail | pass |
| `reference` | BASE plus `reference/pr.diff` | pass | pass |
| `empty` | BASE plus an empty commit | fail | pass |
| `probe` | BASE plus `reference/probe.diff` | fail | recorded |

Keep `infra_status` separate from the verdict. A control that could not run is `infra_error`, never a pass and never a rejection on its own. Fix the environment and rerun.

## Probes

Probes are the only negative controls beyond empty. Good probes

- handle the repro input but not a neighbouring input
- fix one code path when the request implies several
- special-case the literal example from the issue
- return the right value but skip a side effect the request asked for
- change behavior the request did not ask for, in a way the regression suite does not notice

A probe must be something a competent but hurried engineer would plausibly submit. If your first probe is caught trivially, that is fine. If your behavior verifier cannot tell the probe from the reference, the verifier is too weak.

## Accepted alternatives

Each behavior verifier lists `accepted_alternatives`, other correct approaches it would also pass, and `plausible_wrong`, wrong approaches it would fail. If you cannot name at least one accepted alternative, check whether the verifier is testing behavior or implementation.

## Infra versus semantic

Exit codes from `run.sh` and every check

| Code | Meaning | Recorded as |
|---|---|---|
| 0 | pass | `pass` |
| 1 | fail | `fail` |
| 2 or other | could not run | `infra_error`, verdict `unmeasured` |

A task with any blocking verifier `unmeasured` on a required control cannot be emitted.
