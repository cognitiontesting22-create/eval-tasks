# Engineer questions

From Creating a Task and the Release Timeline. The skill reads the PR, the trace if there is one, review comments, and follow-up commits, then asks only what the history cannot answer. Draft an answer to every question first. Ask only the ones you could not answer, in one batched message, and accept short replies.

## The questions

1. What did you really ask for, and what behavior did you expect when it was done? (Show your draft. Ask for corrections, not a rewrite.)
2. Of the review comments and follow-up commits, which were requirements and which were preferences? (List them, pre-tagged, ask for changes.)
3. What would make an attempt unacceptable even if the tests pass? These become blockers. Anything nice to have, and roughly how much each counts? (Offer a default of blockers 100 percent and equal weight for the rest.)
4. How would you verify it? Run tests, or start the app and check a specific behavior? (If click-through, ask for the exact steps so a script or a judge can follow them.)
5. What does the environment need that a fresh clone at the pre-PR commit does not have? Services, seed data, secrets by name, environment variables. Which files or areas must not change?
6. Which MCP tools or live services did the original work use, and what did they give you? (Pre-fill from the trace. Ask only about gaps.)
7. Which configurations should be compared? Fusion and SWE-2 are required. Ultra and others are optional.
8. May I freeze this prompt and these criteria? (Show original request and frozen prompt side by side. Yes freezes the task.)

## How to ask

- One message, numbered, with your drafts inline. The engineer edits rather than writes.
- Accept "looks fine" or a blank as approval of the draft for that question.
- Do not ask about anything already answered by the issue, PR description, trace, or code.
- Do not ask the engineer to rate their own PR or to explain why it took as long as it did. Nothing here is about the engineer.
- If the engineer is unavailable and this is an internal rehearsal, answer from the issue and PR and record `engineer_qa: "none, built from PR and issue"`.

## What the answers feed

| Question | Goes to |
|---|---|
| 1 | `task.md`, `reference/request.md` |
| 2 | `task.md` (requirements), `criteria.md` nice to have (preferences) |
| 3 | `criteria.md` blockers and weights, `verifiers.json` `criterion` rows with `user_stated: true` |
| 4 | `hidden_test/`, or an `llm_judge` check with `deterministic_infeasible` filled in |
| 5 | `meta.json.toolchain`, `install_command`, `verifiers.json` `scope` rows, runner blueprint notes |
| 6 | `meta.json.mcp_dependencies`, `lifted_into_prompt`, `task.md` |
| 7 | `meta.json.configurations` |
| 8 | `meta.json.prompt_approved` |
