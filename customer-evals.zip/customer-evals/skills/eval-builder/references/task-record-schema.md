# Task record schema

Both files are strict. `scripts/validate_record.py` rejects unknown fields and missing required fields. The field list follows the Task record section of Creating a Task in Notion, plus the control results and provenance from `prod_to_eval_v2`.

## meta.json

```json
{
  "schema": "customer-evals.task/1",
  "id": "click-3818",
  "repo": "cognitiontesting22-create/click",
  "upstream_repo": "pallets/click",
  "fork_url": "https://github.com/cognitiontesting22-create/click",
  "base_branch": "eval/click-3818-base",
  "base_sha": "b47c0529e99129d4785fecc2cb39a8ec8b4aa5f8",
  "merge_sha": "00f257bb8e714064bea16425007543bbc0800445",
  "pr_number": 3818,
  "pr_url": "https://github.com/pallets/click/pull/3818",
  "pr_source": "human",
  "issue_url": "https://github.com/pallets/click/issues/3802",
  "merged_at": "2026-08-31",
  "difficulty": "hard",
  "spare": false,
  "language": "python",
  "toolchain": { "python": "3.10.12", "uv": "0.12.16" },
  "install_command": "uv sync --locked --group tests",
  "test_command": "uv run pytest -v --tb=short",
  "timeout_minutes": 45,
  "request_source": "issue",
  "trace_source": "none",
  "engineer_qa": "none, built from PR and issue",
  "mcp_dependencies": [],
  "lifted_into_prompt": [],
  "spoilers_stripped": ["pager policy reference", "prior PR number"],
  "files_touched": { "source": ["src/click/core.py"], "test": ["tests/test_abort_interrupt.py"] },
  "prompt_word_count": 212,
  "prompt_approved": { "by": "rehearsal", "at": "2026-09-18T07:00:00Z" },
  "configurations": ["devin-cli-swe2-medium", "opencode-deepseek", "devin-fusion", "codex-astra-medium"],
  "contamination": { "pr_merged_at": "2026-08-31", "model_release_dates": {} },
  "controls": {
    "base":      { "behavior": "fail", "regression": "pass", "infra_status": "ok" },
    "reference": { "behavior": "pass", "regression": "pass", "infra_status": "ok" },
    "empty":     { "behavior": "fail", "regression": "pass", "infra_status": "ok" },
    "probe":     { "behavior": "fail", "regression": "pass", "infra_status": "ok" }
  },
  "probe_description": "Catches the second interrupt only on the first code path, not during abort reporting",
  "lint": "clean",
  "prompt_leak_check": "clean",
  "decision": "EMIT",
  "decision_reason": "all required controls hold",
  "built_at": "2026-09-18T07:10:00Z",
  "builder": "eval-builder 0.1.0"
}
```

Field notes

- `pr_source` is `human`, `devin`, or another agent name. Results are broken down by source so no option only looks good on its own work.
- `request_source` is one of `trace`, `issue`, `pr_description`, `engineer`.
- `trace_source` is `devin_session`, `local_log`, or `none`. When not `none`, `reference/trace-summary.md` must exist.
- `engineer_qa` is a short string. Either who answered and when, or the rehearsal marker.
- `mcp_dependencies` names every MCP or live service the original work used. `lifted_into_prompt` says what from each went into `task.md`. Every entry in the first list must appear in the second or the task is rejected.
- `controls.*.behavior` and `regression` take `pass`, `fail`, or `unmeasured`. `infra_status` takes `ok` or `infra_error`.
- `decision` is `EMIT` or `REJECT`.
- Never include engineer names. `prompt_approved.by` is a role or a random grader id.

## verifiers.json

Mirrors `prod_to_eval_v2.verifiers/1` closely enough that a task can be lifted into that pipeline later.

```json
{
  "schema": "customer-evals.verifiers/1",
  "task_id": "click-3818",
  "verifiers": [
    {
      "id": "second_interrupt_exits_cleanly",
      "category": "behavior",
      "blocking": true,
      "user_stated": true,
      "weight": 1.0,
      "requirement": "A second Ctrl-C while the abort message is being printed exits with the abort status and no traceback",
      "source": { "kind": "historical_pr", "quote": "hitting Ctrl-C twice shows a traceback", "url": "https://github.com/pallets/click/issues/3802" },
      "check": { "type": "script", "path": "hidden_test/run.sh" },
      "accepted_alternatives": ["catch the second interrupt anywhere in the abort path and exit 1", "install a signal handler for the duration of abort reporting"],
      "plausible_wrong": ["catch the interrupt only in the first handler", "swallow all exceptions during abort"],
      "controls": { "reference": "pass", "empty": "fail", "probe": "fail" },
      "rationale": "Observable from the process exit code and stderr with a subprocess, no internals needed"
    },
    {
      "id": "existing_suite",
      "category": "regression",
      "blocking": true,
      "user_stated": false,
      "weight": 1.0,
      "requirement": "The existing test suite stays green",
      "source": { "kind": "repository", "quote": "uv run pytest -v --tb=short" },
      "check": { "type": "builtin", "name": "existing_suite" },
      "accepted_alternatives": [],
      "plausible_wrong": [],
      "controls": { "reference": "pass", "empty": "pass", "probe": "recorded" },
      "rationale": "Regression control"
    }
  ]
}
```

Field notes

- `category` is one of `behavior`, `regression`, `test_authoring`, `scope`, `criterion`, `process`.
- `blocking` must be true for `behavior` and `regression`. For the other four it may be true only when `user_stated` is true.
- `source.kind` is `user_message`, `user_correction`, `repository`, or `historical_pr`. User-sourced kinds cite `event_index` from the trace.
- `check.type` is `script`, `builtin`, or `llm_judge`. Scripts live under `hidden_test/`. Builtins are `existing_suite`, `no_tree_changes`, `files_untouched`. Judges require `criterion`, `pass_rule`, `evidence`, `deterministic_infeasible`.
- `controls` values are `pass`, `fail`, or `recorded`. `reference` is always `pass`.
- At least one `behavior` verifier and exactly one `regression` verifier are required.

## decision.md

Plain text. First line `EMIT` or `REJECT`. Then the reason, then the control table copied from `meta.json.controls`, then the self-check questions and resolutions.
