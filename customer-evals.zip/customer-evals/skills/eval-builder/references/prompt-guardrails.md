# Prompt guardrails

From Creating a Task in the Customer Evals Workspace. The prompt may be revised from the original request, within these limits.

## Add only what the developer already knew and wanted at the start

- Follow-up messages that turned out to be requirements go into the initial prompt. Runs are one shot and the agent gets no second message.
- What the developer got from MCP tools or live services (the Linear ticket text, the Datadog error, the Figma spec) goes into the prompt as plain text, because attempts run with no MCPs.
- Preferences the developer expressed later that were not requirements stay out of the prompt and may appear in `criteria.md` as nice to have.

## Never add what was learned from the fix

- No file names, function names, class names, or module paths the PR touched.
- No mechanism. Not "add a lock", not "traverse the ancestry", not "check ordering".
- No root cause analysis from the PR description or review thread. Describe the symptom, not the cause, unless the requester themselves stated the cause.
- No issue numbers, PR numbers, references to other PRs, or commit messages.
- No hint that this is an evaluation, that there is a reference solution, or that a hidden test exists.

## Do not hide requirements in the criteria

If the agent needs a fact to succeed, it belongs in `task.md`. `criteria.md` is for the grader and the agent never sees it. Anything that is only in `criteria.md` is a judgment call, not a requirement.

## Shape

- Requester's voice. First person is fine when the source is an issue or a chat message.
- One request. Symptom or need, expected behavior, minimal repro when one exists, environment facts the agent cannot discover from the checkout (for example which command runs the tests).
- Say tests are expected and the suite must stay green.
- Under 300 words. Longer prompts usually mean a spoiler or a second task crept in.
- Do not tell the agent to push, open a PR, or name a branch. The runner does that.

## Leak check

`scripts/check_prompt_leak.py` flags

- any path or basename from `files_touched.source` appearing in `task.md`
- any identifier longer than 5 characters that appears in added lines of `reference/pr.diff` and in `task.md` but not at BASE in the touched files (new names introduced by the fix)
- `#<digits>` matching the PR or issue number
- the words `eval`, `evaluation`, `hidden test`, `reference solution`, `benchmark`
- word count over 300

Fix every finding or record why it is a false positive in `decision.md`.

## Side benefit

Show the engineer the original request and the frozen prompt side by side when asking for approval. The diff between them often shows what the original prompt was missing, which helps the customer prompt better next time.
