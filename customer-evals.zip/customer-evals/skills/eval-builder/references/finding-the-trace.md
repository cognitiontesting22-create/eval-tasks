# Finding the agent trace

From Creating a Task in the Customer Evals Workspace. Getting the trace is the most advanced step for engineers, so walk them through it. The trace is optional. When the PR description and linked issue capture the original request well enough, skip it and say so in `meta.json.trace_source`.

The trace is only used to write the prompt and criteria. It stays in the customer's environment and is never copied into the task folder. Only `reference/trace-summary.md` is kept, and it is never shown to attempting agents.

## Devin

Look for a session link in the PR description or in the PR's first comment. Devin-authored PRs carry one. Read the session's user messages in order. The first is the original request. Every later user message is either a correction, a follow-up requirement, or a preference. Tool results from MCP servers (Linear, Jira, Datadog, Figma, Notion) are the values to lift into the prompt.

## Local agents

The trace lives on the machine where the agent ran. Run this skill locally on that machine, or ask the engineer to connect their machine, then look for the session by repo path and date and confirm the match with the engineer before reading it.

| Agent | Where sessions live | Format |
|---|---|---|
| Claude Code | `~/.claude/projects/<escaped-repo-path>/*.jsonl` | one JSONL per session, user turns have `type: user` |
| Codex CLI | `~/.codex/sessions/` | JSONL per session |
| Devin CLI | `~/.config/devin/` or the path `devin config` prints | check the CLI's own docs for the current layout |
| OpenCode | `~/.local/share/opencode/` | check the CLI's own docs |

These paths change between versions. When a path above is missing, ask the engineer where their agent keeps sessions rather than searching the disk broadly. Never read files outside the agent's session directory.

## No trace

Draft the prompt from the PR description and the linked issue or ticket, then ask the engineer to confirm what they originally asked for and whether anything essential is missing. Record `request_source` accordingly.

## What to extract, whatever the source

Write `reference/trace-summary.md` with

1. The first request, verbatim, with a message index or timestamp
2. Every user correction or follow-up, verbatim, each tagged requirement or preference after the engineer confirms
3. Every MCP or live-service call and the value the agent relied on, summarised as plain text that can go in the prompt
4. Anything the agent was told not to touch
5. The final message the user accepted the work with, if any

## MCP pruning

Attempts run with no MCP servers and no live services. For each dependency in item 3 decide

- Lift. The value is static text (ticket body, error message, spec). Put it in `task.md` in the requester's voice, for example "the ticket says ..."
- Recreate. The dependency is a local service the repo's README already starts (a database container). Note it in `meta.json` so the runner's blueprint includes it
- Reject. The value cannot be reproduced and was essential. Record the reason and stop. Do not build a task whose prompt depends on information the agent cannot have
