---
name: eval-builder
description: Turn a completed pull request into a frozen, one-shot coding eval task with a spoiler-free prompt, behavior-based grading criteria, a hidden behavioral verifier, a plausible wrong-fix probe, and a hidden answer key, then validate it against controls and emit or reject it. Use when an engineer asks to build an eval task from a PR, freeze a task, create a hidden test for a merged change, or prepare tasks for a model or harness comparison.
argument-hint: <PR URL> [--trace <devin session URL | local log path>] [--out <task repo or folder>]
---

# Eval builder

You are helping an engineer turn one completed PR into an eval task that any coding configuration (Devin Fusion, Devin CLI with SWE-2, Codex, OpenCode, Claude Code) can attempt one shot from the pre-PR commit, and that a human can grade with a single "would I merge this" answer. The task must be fair to a different correct implementation and must catch a wrong one.

The method comes from the Customer Evals Workspace in Notion (Creating a Task, Running Judging and Results, Internal Testing Walkthrough parts 1 and 2). The verifier contract comes from `prod_to_eval_v2` in `cognition-research/devin-datagen`. Both are summarised in `references/`, read them before your first task.

Everything runs inside the customer's account. Nothing in this skill opens a PR, pushes to a main branch, or sends code outside the account.

## Inputs

| Input | Required | Where it comes from |
|---|---|---|
| PR URL or PR number plus repo | yes | the engineer |
| Merge state of the PR | yes | git history. Merged PRs are preferred. An unmerged PR is allowed only if the engineer confirms the branch is the accepted answer |
| Agent trace | no | Devin session link in the PR description, a local agent log, or none. See `references/finding-the-trace.md` |
| Original request | yes | trace, linked issue or ticket, PR description, or the engineer. At least one must exist |
| Engineer answers | yes for customer tasks, no for internal OSS rehearsals | the Q&A in step 3 |
| Output location | yes | a folder in the session, plus optionally a dedicated task repository the engineer names. Never the repo the PR is about |

## Output

One folder per task. The attempting agent only ever sees `task.md`.

```
tasks/<task-id>/
  task.md              frozen prompt. The only file an attempting agent sees
  criteria.md          for the human grader. Would merge first, then blockers, then nice to have
  hidden_test/
    run.sh             takes the repo path as $1, exit 0 pass, 1 fail, 2 infra
    <test files>       behavioral tests copied into place by run.sh
  verifiers.json       structured verifier set, see references/task-record-schema.md
  meta.json            provenance and control results, see references/task-record-schema.md
  reference/           answer key, never shown to attempting agents
    pr.diff            BASE to merge commit
    request.md         the original request verbatim, with source URLs or trace pointer
    probe.diff         plausible wrong fix the hidden test must catch
    trace-summary.md   only when a trace exists. What the requester asked, what changed mid-session, what MCPs returned
  decision.md          EMIT or REJECT with the reason and the control table
```

`<task-id>` is `<repo>-<pr-number>`.

## Procedure

Work through the steps in order. Do not start step 5 until the engineer has approved step 4, unless this is an internal rehearsal where you are told to play the engineer.

### 1. Recover the starting state

1. Clone the repo with full history. Find the merge commit for the PR. Try `git log --first-parent <default> --grep "(#N)"`, then `--grep "Merge pull request #N"`, then search for `#N` and say which commit you chose and why.
2. BASE is the merge commit's first parent. Record BASE and MERGE SHAs.
3. Check out BASE and get the test suite green with the repo's own toolchain pins. Record exact versions, install commands, the test command, and wall time. If BASE cannot run in a fresh environment, stop and report. That is a rejection reason, not something to work around.
4. Diff BASE to MERGE. List source files and test files touched. Save the diff to `reference/pr.diff`.

### 2. Recover the request

1. Find the original request in this order. Trace if available, linked issue or ticket, PR description, review comments, follow-up commits, engineer.
2. Write `reference/request.md` with the requester's words verbatim and every source URL. If the words came from a trace, cite the message index.
3. If a trace exists, write `reference/trace-summary.md`. Record what the user first asked, every correction or follow-up the user gave, and every value an MCP or live service returned that the agent then relied on (ticket text, a Datadog error, a Figma measurement). These lifts go into the prompt in step 4.
4. Note every live dependency the original work used (MCP servers, services, seed data, secrets). Decide per item whether its output can be lifted into the prompt. If any essential item cannot be lifted, the PR is unsuitable. Record it and stop.

### 3. Ask the engineer only what history cannot answer

Read `references/engineer-questions.md`. Draft answers to every question from what you already have, then ask only the ones you could not answer. Batch them into one message. Typical ones

- What was really being asked for, and what behavior is expected
- Which review comments and follow-ups were requirements and which were preferences
- What makes an output unacceptable (blockers) versus nice to have, and weights
- How to verify. Tests, or start the app and check specific behavior
- What the environment needs and which files or areas must not change
- Which configurations to compare (Fusion and SWE-2 required, others optional)

For internal OSS rehearsals with no engineer, answer these yourself from the issue and PR, and say so in `meta.json` under `engineer_qa: "none, built from PR and issue"`.

### 4. Draft and freeze the prompt and criteria

Write `task.md`. Rules, from Creating a Task and the guardrails in `references/prompt-guardrails.md`

- Written in the requester's voice. One request, no follow-up, addressed to an engineer who has never seen the issue
- Describe the wrong or missing behavior and the wanted behavior, with a minimal repro when one exists
- Lift in what the developer knew and wanted at the start, including follow-ups that were requirements and what MCPs returned. Runs are one shot with no MCPs
- Do not name files, functions, or the mechanism of the fix. Do not mention issue numbers, PR numbers, other PRs, or that this is an eval
- Do not hide an essential requirement in `criteria.md`. If the agent needs it, it goes in `task.md`
- Say the change should include tests and the existing suite must stay green. Give the test command
- Do not tell the agent to open a PR or push. The runner handles that
- Under 300 words

Write `criteria.md` with three sections. Merge question ("Would you merge this?" is the only required grade). Blockers. Nice to have. Criteria describe behavior, never how the original PR did it.

Run `scripts/check_prompt_leak.py tasks/<id>` and fix every finding. Then show the engineer the original request and the frozen prompt side by side, plus the criteria, and get an explicit yes. Record the approval in `meta.json`. After this point the prompt does not change.

### 5. Write the verifiers

Read `references/verifier-rules.md`. Write `hidden_test/` and `verifiers.json`.

- At least one `behavior` verifier that tests the requested behavior through the public API or CLI. It is blocking
- One `regression` verifier that runs the repo's existing suite, blocking
- Optional `scope`, `criterion`, `process` verifiers, advisory unless the engineer stated them as requirements
- Do not copy the PR's own tests verbatim. Reuse the scenarios, write the file yourself
- Never grep source, inspect an AST, call private helpers, or mock without a written justification. `scripts/lint_verifiers.py` rejects these
- `hidden_test/run.sh <repo>` copies the test files into place, runs only them, exits 0 on pass, 1 on fail, 2 when the test could not run. Exit 2 is infra, not a verdict

### 6. Write the probe

A probe is a plausible wrong fix. The kind an agent submits that looks right but is not. Handles the repro case but not a neighbouring one, fixes one code path but not another, special-cases the exact input from the issue, or changes behavior the request did not ask for. Write it as a patch against BASE in `reference/probe.diff` and describe in one line what it gets wrong.

### 7. Run the controls

`scripts/verify_task.sh <repo-clone> tasks/<id>` replays every control and writes `meta.json.controls`. Required outcomes

| Control | Tree | Behavior verifier | Regression verifier |
|---|---|---|---|
| base | BASE unchanged | must fail | must pass |
| reference | BASE plus `pr.diff` | must pass | must pass |
| empty | BASE plus an empty commit | must fail | must pass |
| probe | BASE plus `probe.diff` | must fail | pass or fail, record it |

If the probe passes the behavior verifier, strengthen the verifier until the probe fails, then rerun all four controls. Never weaken the probe. If any control returns infra (exit 2), fix the environment and rerun. An unmeasured control is never a pass.

### 8. Self check, then emit or reject

1. Read `task.md` as someone who has never seen the issue. List every question you would ask before starting. Put answers in `task.md`, or note judgment calls in `criteria.md`.
2. Confirm a different reasonable implementation would pass the behavior verifier. If the verifier only accepts the original PR's approach, rewrite it.
3. Write `meta.json` per `references/task-record-schema.md` and validate it with `scripts/validate_record.py tasks/<id>`. Unknown fields fail.
4. Write `decision.md`. EMIT only if base fails, reference passes, empty fails, probe fails, regression passes on base and reference, lint is clean, the prompt leak check is clean, and the engineer approved the frozen prompt (or the rehearsal flag is set). Otherwise REJECT with the first failing reason. A rejected task keeps its folder so the reason is reviewable.

### 9. Save and report

Save the task folder in the parent session before any run starts. If the engineer named a dedicated task repository, push a branch there and open one PR for review in that repository only. Report a table with task id, difficulty, base fail, reference pass, empty fail, probe fail, regression, decision, prompt word count. List the self-check questions and how each was resolved, spoilers stripped, and anything that would make a headless run flaky.

## For open source rehearsals

Two extra rules from Internal Testing Walkthrough part 2

- Read the upstream issue and PR during authoring, since you are playing the engineer. If a public issue spells out the fix in a way a harness could search for, strip the identifying details or pick another PR
- Record the PR merge date next to the release dates of every model being compared in `meta.json.contamination`, so readers can judge the risk

## What this skill does not do

Running the task across configurations, collecting rows from outside the children, trace auditing for peeking, and the results file belong to the runner (next skill in this plugin). Automated grading and other-harness runs are internal and never shown to the customer.
