<!-- Requester's voice. Symptom, expected behavior, minimal repro, test command. Under 300 words. No file names, mechanisms, issue or PR numbers. Delete this comment. -->

When I <do X>, <wrong behavior happens>. I expected <wanted behavior>.

Steps to reproduce

1. ...
2. ...

Please fix this and add tests covering it. The existing suite must stay green. Run it with `<test command>`.
