EMIT

all required controls hold

| control | behavior | regression | infra |
|---|---|---|---|
| base | fail | pass | ok |
| reference | pass | pass | ok |
| empty | fail | pass | ok |
| probe | fail | pass | ok |

probe: <one line on what the probe gets wrong>

## Self check

- Q ... resolved by ...
