# Criteria

## Merge question

Would you merge this? Yes or no. This is the only required grade.

## Blockers

Any one of these means no.

- The requested behavior is not observable. <state it in behavior terms>
- No test was added for the new behavior.
- The existing suite is broken.
- The change reaches well outside the request.

## Nice to have

Optional. Tick any that apply.

- <something the original PR did beyond the minimum>
- <a preference the requester expressed later>

## Judgment calls

Things a reasonable implementer could decide either way. Do not fail an attempt for these.

- <...>
