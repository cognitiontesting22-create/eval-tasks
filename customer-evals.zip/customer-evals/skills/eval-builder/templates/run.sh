#!/usr/bin/env bash
# hidden_test/run.sh <repo-path>
# Copies the hidden test into place, runs only it, exits 0 pass, 1 fail, 2 could not run.
set -u
REPO=${1:?repo path required}
HERE=$(cd "$(dirname "$0")" && pwd)
cd "$REPO" || exit 2
cp "$HERE/test_hidden_behavior.py" tests/ || exit 2
uv run pytest -q tests/test_hidden_behavior.py
rc=$?
rm -f tests/test_hidden_behavior.py
case $rc in 0) exit 0;; 1) exit 1;; *) exit 2;; esac
