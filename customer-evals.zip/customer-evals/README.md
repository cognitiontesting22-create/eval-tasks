# customer-evals plugin

A Devin plugin for customer-owned coding evals. Install it in the customer's Devin account. Version 0.1.0 ships one skill, `eval-builder`, which turns a completed PR into a frozen, rerunnable one-shot task. The runner skill (child sessions per configuration, parent-side result rows, trace audit, results file) is the next skill and is not in this version.

## Layout

```
customer-evals/
  .devin-plugin/plugin.json
  README.md
  rules/eval-task-hygiene.md          model-triggered rule, applies while touching task records
  skills/eval-builder/
    SKILL.md                           the procedure
    references/
      verifier-rules.md                categories, lint, controls, probes (from prod_to_eval_v2)
      task-record-schema.md            meta.json and verifiers.json, strict
      prompt-guardrails.md             what may and may not go in task.md
      finding-the-trace.md             Devin, local agents, no trace, MCP pruning
      engineer-questions.md            the eight questions and where each answer lands
    scripts/
      verify_task.sh                   replays base, reference, empty, probe controls into meta.json
      lint_verifiers.py                schema and anti-pattern lint for verifiers.json and hidden_test/
      check_prompt_leak.py             spoiler and size check for task.md
      validate_record.py               strict meta.json validation and EMIT or REJECT decision
    templates/                         task.md, criteria.md, run.sh, decision.md starters
```

## Where the design comes from

- Customer Evals Workspace in Notion. Creating a Task gives the task-candidate rules, the trace policy, MCP pruning, prompt guardrails, the criteria shape, and the pre-run checks. Running, Judging, and Results gives fair-run rules and the grading question. Internal Testing Walkthrough part 2 gives the open source rehearsal rules.
- `experimental/deniz/prod_to_eval_v2` in `cognition-research/devin-datagen`. Verifier categories, blocking rules, the lint, the reference, empty and probe controls, infra versus semantic status, and the emit or reject decision. The Evalon, pre-AMI, and multi-model audit parts are intentionally not carried over.
- The manual task-builder prompt used for the click, hono, and urfave/cli rehearsal. The folder layout and the base fail, merge pass, probe fail requirement.

## Trying it

```
python3 skills/eval-builder/scripts/lint_verifiers.py tasks/<id>
python3 skills/eval-builder/scripts/check_prompt_leak.py tasks/<id>
bash    skills/eval-builder/scripts/verify_task.sh <repo-clone> tasks/<id>
python3 skills/eval-builder/scripts/validate_record.py tasks/<id> --write-decision
```

All four were exercised on a synthetic repository. A good first real test is to point the skill at one of the eight rehearsal tasks and compare its output with the hand-built record.

## Known gaps in 0.1.0

- `verify_task.sh` treats any exit 1 from the test command as a semantic fail. A missing test runner also exits 1 in some tools. `run.sh` should check its tooling and exit 2 when it is absent.
- The trace paths for local agents are best effort and will drift between versions.
- No runner skill yet. The builder stops at a saved task folder and an optional PR to a dedicated task repository.
