---
trigger: model
description: Applies whenever a task record, task.md, criteria.md, hidden test, probe, or reference patch for a customer eval is being read or written.
---
# Eval task hygiene

- Task creation opens no pull requests and pushes nothing to any main branch. Task records are saved in the parent session and, if the customer chose one, in a dedicated task repository. Never write a task record into the repository the task is about.
- `task.md` is the only file an attempting agent may ever see. Never copy anything from `reference/`, `criteria.md`, or `hidden_test/` into it.
- Never paste secrets, tokens, or internal hostnames into any task file. Refer to secrets by name.
- Grading is friendly by design. No engineer names, review times, or effort metrics go into any task or results file. Use a random grader id when one is needed.
- A task that cannot pass every required control is rejected with a reason. Never weaken a control or a probe to make a task pass.
